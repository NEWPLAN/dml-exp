#ifndef SERVER_H_
#define SERVER_H_

int run_server();

#endif /* server.h */

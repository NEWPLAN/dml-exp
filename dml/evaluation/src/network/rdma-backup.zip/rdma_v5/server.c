#include <fcntl.h>
#include <sys/stat.h>

#include "common.h"
#include "messages.h"

#define MAX_FILE_NAME 256

struct conn_context
{
  //  char *buffer;
  //  struct ibv_mr *buffer_mr;

  char *buffer_pool;
  struct ibv_mr *buffer_pool_mr;

  // struct message *msg;
  // struct ibv_mr *msg_mr;

  struct message *msg_group[MAX_DATA_IN_FLIGHT];
  struct ibv_mr *msg_group_mr[MAX_DATA_IN_FLIGHT];

  int fd;
  char file_name[MAX_FILE_NAME];
  size_t recv_bytes;
  char peer_addr[16];
  uint32_t ctx_id;
};

//struct conn_context *ctx_group[20];
//static uint32_t ctx_id = 0;

static void send_message(struct rdma_cm_id *id)
{
  struct conn_context *ctx = (struct conn_context *)id->context;

  struct ibv_send_wr wr, *bad_wr = NULL;
  struct ibv_sge sge;

  memset(&wr, 0, sizeof(wr));

  wr.wr_id = (uintptr_t)id;
  wr.opcode = IBV_WR_SEND;
  wr.sg_list = &sge;
  wr.num_sge = 1;
  wr.send_flags = IBV_SEND_SIGNALED;

  sge.addr = (uintptr_t)ctx->msg_group[0];
  sge.length = sizeof(struct message);
  sge.lkey = ctx->msg_group_mr[0]->lkey;

  TEST_NZ(ibv_post_send(id->qp, &wr, &bad_wr));
}

static void post_receive(struct rdma_cm_id *id)
{
  struct ibv_recv_wr wr, *bad_wr = NULL;

  memset(&wr, 0, sizeof(wr));

  wr.wr_id = (uintptr_t)id;
  wr.sg_list = NULL;
  wr.num_sge = 0;

  TEST_NZ(ibv_post_recv(id->qp, &wr, &bad_wr));
}

static void on_pre_conn(struct rdma_cm_id *id)
{
  struct conn_context *ctx = (struct conn_context *)malloc(sizeof(struct conn_context));

  id->context = ctx;

  ctx->file_name[0] = '\0'; // take this to mean we don't have the file name

  //  posix_memalign((void **)&ctx->buffer, sysconf(_SC_PAGESIZE), BUFFER_SIZE);
  //  TEST_Z(ctx->buffer_mr = ibv_reg_mr(rc_get_pd(), ctx->buffer, BUFFER_SIZE, IBV_ACCESS_LOCAL_WRITE | IBV_ACCESS_REMOTE_WRITE));

  posix_memalign((void **)&ctx->buffer_pool, sysconf(_SC_PAGESIZE), BUFFER_SIZE * MAX_DATA_IN_FLIGHT);
  TEST_Z(ctx->buffer_pool_mr = ibv_reg_mr(rc_get_pd(), ctx->buffer_pool, BUFFER_SIZE * MAX_DATA_IN_FLIGHT, IBV_ACCESS_LOCAL_WRITE | IBV_ACCESS_REMOTE_WRITE));

  //  posix_memalign((void **)&ctx->msg, sysconf(_SC_PAGESIZE), sizeof(*ctx->msg));
  //  TEST_Z(ctx->msg_mr = ibv_reg_mr(rc_get_pd(), ctx->msg, sizeof(*ctx->msg), 0));
  for (int msg_index = 0; msg_index < MAX_DATA_IN_FLIGHT; msg_index++)
  {
    posix_memalign((void **)&ctx->msg_group[msg_index], sysconf(_SC_PAGESIZE), sizeof(struct message));
    TEST_Z(ctx->msg_group_mr[msg_index] = ibv_reg_mr(rc_get_pd(), ctx->msg_group[msg_index], sizeof(struct message), 0));
  }

  post_receive(id);
}

// exchange local information with peer.
static void on_connection(struct rdma_cm_id *id)
{
  struct conn_context *ctx = (struct conn_context *)id->context;

  ctx->msg_group[0]->id = MSG_MR;
  //ctx->msg->data.mr.addr = (uintptr_t)ctx->buffer_mr->addr;
  //ctx->msg->data.mr.rkey = ctx->buffer_mr->rkey;
  //using new buffer
  ctx->msg_group[0]->data.mr.addr = (uintptr_t)ctx->buffer_pool_mr->addr;
  ctx->msg_group[0]->data.mr.rkey = ctx->buffer_pool_mr->rkey;

  send_message(id);
}

static void on_completion(struct ibv_wc *wc)
{
  struct rdma_cm_id *id = (struct rdma_cm_id *)(uintptr_t)wc->wr_id;
  struct conn_context *ctx = (struct conn_context *)id->context;

  if (wc->opcode == IBV_WC_RECV_RDMA_WITH_IMM)
  {
    uint32_t imm_data_recv = ntohl(wc->imm_data);

    uint32_t size = imm_data_recv & 0XFFFFFF;
    uint32_t buffer_id = (imm_data_recv >> 24) & 0xFF;
    //printf("Recv buffer id: %u, size: %u, data:[%c - %c]\n", buffer_id, size, ctx->buffer_pool[buffer_id * BUFFER_SIZE], ctx->buffer_pool[buffer_id * BUFFER_SIZE + size - 1]);
    if ('0' != ctx->buffer_pool[buffer_id * BUFFER_SIZE] - buffer_id ||
        '0' != ctx->buffer_pool[buffer_id * BUFFER_SIZE + size - 1] - buffer_id)
    {
      printf("Unknown error: Recv buffer id: %u, size: %u, data:[%c - %c]\n", buffer_id, size, ctx->buffer_pool[buffer_id * BUFFER_SIZE], ctx->buffer_pool[buffer_id * BUFFER_SIZE + size - 1]);
      exit(-1);
    }

    //ctx->buffer_pool[0] = ctx->buffer_pool[size - 1] = 0;

    if (size == 0)
    {
      ctx->msg_group[0]->id = MSG_DONE;
      send_message(id);

      // don't need post_receive() since we're done with this connection
    }
    else if (ctx->file_name[0])
    {
      //ssize_t ret;

      //printf("received %i bytes.\n", size);
      ctx->recv_bytes += size;
      if (ctx->recv_bytes > 10000000000)
      {
        printf("[%s]received %lu bytes %p.\n", ctx->file_name, ctx->recv_bytes, ctx);
        ctx->recv_bytes = 0;
      }

      /*
      ret = write(ctx->fd, ctx->buffer, size);

      if (ret != size)
        rc_die("write() failed");
      */
      ctx->buffer_pool[buffer_id * BUFFER_SIZE] = ctx->buffer_pool[buffer_id * BUFFER_SIZE + size - 1] = 0;
      post_receive(id);

      ctx->msg_group[0]->id = MSG_READY;
      send_message(id);
    }
    else
    {
      size = (size > MAX_FILE_NAME) ? MAX_FILE_NAME : size;
      memcpy(ctx->file_name, ctx->buffer_pool, size);
      ctx->file_name[size] = '\0';

      printf("opening file %s\n", ctx->file_name);

      /*
      ctx->fd = open(ctx->file_name, O_WRONLY | O_CREAT | O_EXCL, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);

      if (ctx->fd == -1)
        rc_die("open() failed");
      */
      ctx->buffer_pool[buffer_id * BUFFER_SIZE] = ctx->buffer_pool[buffer_id * BUFFER_SIZE + size - 1] = 0;
      post_receive(id);

      ctx->msg_group[0]->id = MSG_READY;
      send_message(id);
    }
  }
}

static void on_disconnect(struct rdma_cm_id *id)
{
  struct conn_context *ctx = (struct conn_context *)id->context;

  //close(ctx->fd);

  ibv_dereg_mr(ctx->buffer_pool_mr);
  ibv_dereg_mr(ctx->msg_group_mr[0]);

  free(ctx->buffer_pool);
  free(ctx->msg_group[0]);

  printf("finished transferring %s\n", ctx->file_name);

  free(ctx);
}

int main(int argc, char **argv)
{
  rc_init(
      on_pre_conn,
      on_connection,
      on_completion,
      on_disconnect);

  printf("waiting for connections. interrupt (^C) to exit.\n");

  rc_server_loop(DEFAULT_PORT);

  return 0;
}

#ifndef __RDMA_SERVER_H__
#define __RDMA_SERVER_H__
#include <thread>
#include <vector>
#include <rdma/rdma_cma.h>
#include "RDMABase.h"

class RDMAServer : public RDMABase
{
public:
    RDMAServer(RDMAAdapter &rdma_adapter);
    ~RDMAServer();

    void setup();
    void start_service();

protected:
    virtual void *send_poll_cq(void *_id);
    virtual void *recv_poll_cq(void *_id);
    virtual void rdma_on_connection(struct rdma_cm_id *id);
    virtual void rdma_build_context(struct rdma_cm_id *id);

private:
    void _recv_loops();
    void _init();

private:
    std::thread *aggregator_thread = nullptr;
    RDMAAdapter rdma_adapter_;
    std::vector<std::thread *> recv_threads;
};

#endif
#include "RDMAServer.h"
#include <iostream>
#include <rdma/rdma_cma.h>

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

#include <iostream>

#include <thread>
#include <fcntl.h>
//#include "../utils/ATimer.h"

RDMAServer::RDMAServer(RDMAAdapter &rdma_adapter)
{
    this->rdma_adapter_ = rdma_adapter;
    std::cout << "Creating RDMAServer" << std::endl;
}
RDMAServer::~RDMAServer()
{
    std::cout << "Destroy RDMAServer" << std::endl;
}

void RDMAServer::setup()
{
    std::cout << "Setup RDMAServer" << std::endl;
    this->_init();
}
void RDMAServer::start_service()
{
    std::cout << "RDMA is starting service" << std::endl;
}

void RDMAServer::_recv_loops()
{
    std::cout << "In RDMA _recv_loops" << std::endl;
    struct rdma_cm_event *event = NULL;
    struct rdma_conn_param cm_params;
    int connecting_client_cnt = 0;
    int client_counts = 12;
    printf("server is inited done (RDMA), waiting for %d client connecting....:)\n", client_counts);
    rdma_build_params(&cm_params);

    while (rdma_get_cm_event(this->rdma_adapter_.event_channel, &event) == 0)
    {
        struct rdma_cm_event event_copy;

        memcpy(&event_copy, event, sizeof(*event));
        rdma_ack_cm_event(event);

        if (event_copy.event == RDMA_CM_EVENT_CONNECT_REQUEST)
        {
            //std::cout << "Recv a RDMA_CM_EVENT_CONNECT_REQUEST" << std::endl;
            rdma_build_connection(event_copy.id);
            rdma_on_pre_conn(event_copy.id);
            TEST_NZ(rdma_accept(event_copy.id, &cm_params));
        }
        else if (event_copy.event == RDMA_CM_EVENT_ESTABLISHED)
        {
            rdma_on_connection(event_copy.id);
            this->rdma_adapter_.recv_rdma_cm_id.push_back(event_copy.id);

            struct sockaddr_in *client_addr = (struct sockaddr_in *)rdma_get_peer_addr(event_copy.id);
            printf("client[%s,%d] is connecting (RDMA) now... \n", inet_ntoa(client_addr->sin_addr), client_addr->sin_port);
            connecting_client_cnt++;
            if (connecting_client_cnt == client_counts)
                break;
        }
        else if (event_copy.event == RDMA_CM_EVENT_DISCONNECTED)
        {
            rdma_destroy_qp(event_copy.id);
            rdma_on_disconnect(event_copy.id);
            rdma_destroy_id(event_copy.id);
            connecting_client_cnt--;
            if (connecting_client_cnt == 0)
                break;
        }
        else
        {
            rc_die("unknown event server\n");
        }
    }
    printf("%d clients have connected to my node (RDMA), ready to receiving loops\n", client_counts);

    while (1)
    {
        std::cout << "Should never get here" << std::endl;
        std::this_thread::sleep_for(std::chrono::seconds(10));
    }

    printf("RDMA recv loops exit now...\n");
    return;
}
void RDMAServer::_init()
{

    int init_loops = 0;
    struct sockaddr_in sin;
    printf("init a server (RDMA)....\n");
    memset(&sin, 0, sizeof(sin));
    sin.sin_family = AF_INET;                              /*ipv4*/
    sin.sin_port = htons(this->rdma_adapter_.server_port); /*server listen public ports*/
    sin.sin_addr.s_addr = INADDR_ANY;                      /*listen any connects*/

    TEST_Z(this->rdma_adapter_.event_channel = rdma_create_event_channel());
    TEST_NZ(rdma_create_id(this->rdma_adapter_.event_channel, &this->rdma_adapter_.listener, NULL, RDMA_PS_TCP));

    while (rdma_bind_addr(this->rdma_adapter_.listener, (struct sockaddr *)&sin))
    {
        std::cerr << "Server init failed (RDMA): error in bind socket, will try it again in 2 seconds..." << std::endl;
        if (init_loops > 10)
        {
            rdma_destroy_id(this->rdma_adapter_.listener);
            rdma_destroy_event_channel(this->rdma_adapter_.event_channel);
            exit(-1);
        }
        std::this_thread::sleep_for(std::chrono::seconds(2));
        init_loops++;
    }

    int client_counts = 12;
    if (rdma_listen(this->rdma_adapter_.listener, client_counts))
    {
        std::cerr << "server init failed (RDMA): error in server listening" << std::endl;
        rdma_destroy_id(this->rdma_adapter_.listener);
        rdma_destroy_event_channel(this->rdma_adapter_.event_channel);
        exit(-1);
    }
    this->_recv_loops();
    //this->aggregator_thread = new std::thread(RDMAServer::_recv_loops, this);
}

void *RDMAServer::send_poll_cq(void *_id)
{
    std::cout << "RDMAServer will never send data" << std::endl;
    exit(-1);
}
void *RDMAServer::recv_poll_cq(void *_id)
{
    struct ibv_cq *cq = NULL;
    struct ibv_wc wc[MAX_CONCURRENCY * 2];
    struct rdma_cm_id *id = (rdma_cm_id *)_id;

    struct RDMAContext *ctx = (struct RDMAContext *)id->context;
    void *ev_ctx = NULL;

    while (true)
    {
        TEST_NZ(ibv_get_cq_event(ctx->comp_channel, &cq, &ev_ctx));
        ibv_ack_cq_events(cq, 1);
        TEST_NZ(ibv_req_notify_cq(cq, 0));

        int wc_num = ibv_poll_cq(cq, MAX_CONCURRENCY * 2, wc);

        for (int index = 0; index < wc_num; index++)
        {
            if (wc[index].status == IBV_WC_SUCCESS)
            {
                /*****here to modified recv* wc---->wc[index]****/
                //printf("in receive poll cq\n");

                uint32_t recv_len;
                concurrency_recv_by_RDMA(id, &wc[index], recv_len);
            }
            else
            {
                printf("\nwc = %s\n", ibv_wc_status_str(wc[index].status));
                rc_die("poll_cq: status is not IBV_WC_SUCCESS");
            }
        }
    }
    return NULL;
}
void RDMAServer::rdma_on_connection(struct rdma_cm_id *id)
{
    struct RDMAContext *new_ctx = (struct RDMAContext *)id->context;
    int index = 0;
    new_ctx->k_exch[0]->id = MSG_MR;
    new_ctx->k_exch[0]->md5 = 6666;

    log_info("k_exch md5 is %llu\n", new_ctx->k_exch[0]->md5);

    for (index = 0; index < MAX_CONCURRENCY; index++)
    {
        new_ctx->k_exch[0]->key_info[index].addr = (uintptr_t)(new_ctx->buffer_mr->addr + (index * BUFFER_SIZE));
        new_ctx->k_exch[0]->key_info[index].rkey = (new_ctx->buffer_mr->rkey);
    }

    {
        new_ctx->k_exch[0]->bitmap.addr = (uintptr_t)(new_ctx->bitmap_mr[0]->addr);
        new_ctx->k_exch[0]->bitmap.rkey = new_ctx->bitmap_mr[0]->rkey;
    }

    //send to myself info to peer
    {
        struct ibv_send_wr wr, *bad_wr = NULL;
        struct ibv_sge sge;

        memset(&wr, 0, sizeof(wr));

        wr.wr_id = (uintptr_t)id;
        wr.opcode = IBV_WR_SEND;
        wr.sg_list = &sge;
        wr.num_sge = 1;
        wr.send_flags = IBV_SEND_SIGNALED;

        sge.addr = (uintptr_t)(new_ctx->k_exch[0]);
        sge.length = sizeof(KeyExchanger);
        sge.lkey = new_ctx->k_exch_mr[0]->lkey;

        TEST_NZ(ibv_post_send(id->qp, &wr, &bad_wr));
    }
    log_info("share my registed mem rx_buffer for peer write to\n");
}

static int client_index = 0;
void RDMAServer::rdma_build_context(struct rdma_cm_id *id)
{
    RDMABase::rdma_build_context(id);

    struct RDMAContext *s_ctx = (struct RDMAContext *)id->context;

    s_ctx->client_index = client_index++;
    std::thread *recv_thread = new std::thread([this, id]() {
        this->recv_poll_cq((void *)id);
    });
    recv_threads.push_back(recv_thread);
}

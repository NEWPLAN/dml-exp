#ifndef __RDMA_CLIENT_H__
#define __RDMA_CLIENT_H__
#include <string>
#include "RDMABase.h"
#include <thread>

class RDMAClient : public RDMABase
{
public:
    RDMAClient(RDMAAdapter &rdma_adapter);
    ~RDMAClient();

    void setup();
    void start_service();

protected:
    virtual void *send_poll_cq(void *_id);
    virtual void *recv_poll_cq(void *_id);
    virtual void rdma_on_connection(struct rdma_cm_id *id);

private:
    void _send_loops();
    void _init();

private:
    int port_ = 2020;
    std::string ip_addr_;

    std::thread *send_thread = nullptr;
    RDMAAdapter rdma_adapter_;
};

#endif
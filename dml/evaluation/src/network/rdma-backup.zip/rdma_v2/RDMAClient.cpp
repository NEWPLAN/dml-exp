#include "RDMABase.h"
#include "RDMAClient.h"

#include <iostream>
#include <rdma/rdma_cma.h>

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

#include <iostream>

#include <thread>
#include <fcntl.h>

RDMAClient::RDMAClient(RDMAAdapter &rdma_adapter)
{
    this->rdma_adapter_ = rdma_adapter;
    std::cout << "Creating RDMAClient" << std::endl;
}
RDMAClient::~RDMAClient()
{
    std::cout << "Destroying RDMAClient" << std::endl;
}

void RDMAClient::setup()
{
    std::cout << "Configure RDMAClient" << std::endl;
    this->_init();
}
void RDMAClient::start_service()
{
    std::cout << "RDMAClient starts service" << std::endl;
}

void RDMAClient::_send_loops()
{
    std::cout << "In RDMAClient send loops" << std::endl;
}
void RDMAClient::_init()
{
    std::cout << "In RDMAClient init" << std::endl;
    std::cout << "client inited (RDMA) start" << std::endl;
    for (size_t index = 0; index < 1; index++)
    {
        struct rdma_cm_id *conn = NULL;
        struct rdma_event_channel *ec = NULL;
        std::string local_eth = this->rdma_adapter_.client_ip; /*get each lev ip*/
        struct sockaddr_in ser_in, local_in;                   /*server ip and local ip*/
        int connect_count = 0;
        memset(&ser_in, 0, sizeof(ser_in));
        memset(&local_in, 0, sizeof(local_in));

        /*bind remote socket*/
        ser_in.sin_family = AF_INET;
        ser_in.sin_port = htons(this->rdma_adapter_.server_port); /*connect to public port remote*/
        inet_pton(AF_INET, this->rdma_adapter_.server_ip.c_str(), &ser_in.sin_addr);

        /*bind local part*/
        local_in.sin_family = AF_INET;
        std::cout << local_eth.c_str() << "----->" << this->rdma_adapter_.server_ip.c_str() << std::endl;
        inet_pton(AF_INET, local_eth.c_str(), &local_in.sin_addr);

        TEST_Z(ec = rdma_create_event_channel());
        TEST_NZ(rdma_create_id(ec, &conn, NULL, RDMA_PS_TCP));
        TEST_NZ(rdma_resolve_addr(conn, (struct sockaddr *)(&local_in), (struct sockaddr *)(&ser_in), TIMEOUT_IN_MS));

        struct rdma_cm_event *event = NULL;
        struct rdma_conn_param cm_params;

        rdma_build_params(&cm_params);
        while (rdma_get_cm_event(ec, &event) == 0)
        {
            struct rdma_cm_event event_copy;
            memcpy(&event_copy, event, sizeof(*event));
            rdma_ack_cm_event(event);
            if (event_copy.event == RDMA_CM_EVENT_ADDR_RESOLVED)
            {
                rdma_build_connection(event_copy.id);
                rdma_on_pre_conn(event_copy.id);
                TEST_NZ(rdma_resolve_route(event_copy.id, TIMEOUT_IN_MS));
            }
            else if (event_copy.event == RDMA_CM_EVENT_ROUTE_RESOLVED)
            {
                TEST_NZ(rdma_connect(event_copy.id, &cm_params));
            }
            else if (event_copy.event == RDMA_CM_EVENT_ESTABLISHED)
            {
                //struct RDMAContext *ctx = (struct RDMAContext *)event_copy.id->context;

                this->send_thread = new std::thread([this, event_copy]() {
                    this->send_poll_cq((void *)(event_copy.id));
                });

                std::cout << local_eth << " has connected to server[ " << this->rdma_adapter_.server_ip << " , " << this->rdma_adapter_.server_port << " ]" << std::endl;

                {
                    rdma_on_connection(event_copy.id);
                }
                break;
            }
            else if (event_copy.event == RDMA_CM_EVENT_REJECTED)
            {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
                connect_count++;

                rdma_on_disconnect(event_copy.id);
                rdma_destroy_qp(event_copy.id);
                rdma_destroy_id(event_copy.id);
                rdma_destroy_event_channel(ec);

                if (connect_count > 10 * 300) /*after 600 seconds, it will exit.*/
                {
                    //release all resources and close all;

                    std::cerr << 300 << "seconds is passed, error in connect to server" << this->rdma_adapter_.server_ip << ", check your network condition" << std::endl;
                    exit(-1);
                }
                else
                {
                    if (connect_count % 10 == 0)
                        std::cout << "Failed when connect to server, Check your Server [" << this->rdma_adapter_.server_ip << ":" << this->rdma_adapter_.server_port << "] is launched" << std::endl;

                    TEST_Z(ec = rdma_create_event_channel());
                    TEST_NZ(rdma_create_id(ec, &conn, NULL, RDMA_PS_TCP));
                    TEST_NZ(rdma_resolve_addr(conn, (struct sockaddr *)(&local_in), (struct sockaddr *)(&ser_in), TIMEOUT_IN_MS));
                }
            }
            else
            {
                printf("event = %d\n", event_copy.event);
                rc_die("unknown event client\n");
            }
        }
    }
    std::cout << "client inited done" << std::endl;
    while (1)
    {
        //std::cout << "main thread sleep for 10 seconds" << std::endl;
        std::this_thread::sleep_for(std::chrono::seconds(10));
    }
}

void *RDMAClient::recv_poll_cq(void *_id)
{
    std::cout << "RDMAClient will never start the recv_poll_cq" << std::endl;
    return 0;
}

void *RDMAClient::send_poll_cq(void *_id)
{
    //log_info("In client function [%d]:%s\n", __LINE__, __func__);
    struct ibv_cq *cq = NULL;
    struct ibv_wc wc[MAX_CONCURRENCY * 2];
    struct rdma_cm_id *id = (rdma_cm_id *)_id;

    struct RDMAContext *ctx = (struct RDMAContext *)id->context;
    void *ev_ctx = NULL;

    int mem_used = 0;

    while (1)
    {
        TEST_NZ(ibv_get_cq_event(ctx->comp_channel, &cq, &ev_ctx));
        ibv_ack_cq_events(cq, 1);
        TEST_NZ(ibv_req_notify_cq(cq, 0));

        int wc_num = ibv_poll_cq(cq, MAX_CONCURRENCY * 2, wc);

        if (wc_num < 0)
        {
            perror("fatal error in ibv_poll_cq, -1");
            exit(-1);
        }

        for (int index = 0; index < wc_num; index++)
        {
            if (wc[index].status == IBV_WC_SUCCESS)
            {
                concurrency_send_by_RDMA(&wc[index], mem_used);
            }
            else
            {
                printf("\nwc = %s\n", ibv_wc_status_str(wc[index].status));
                rc_die("poll_cq: status is not IBV_WC_SUCCESS");
            }
        }
        if (mem_used)
        {
            //struct RDMAContext *ctx = (struct RDMAContext *)id->context;
            for (mem_used; mem_used < MAX_CONCURRENCY; mem_used++)
            {
                send_tensor(id, mem_used);
            } /*send used next buffer*/
        }
    }
    return NULL;
}

void RDMAClient::rdma_on_connection(struct rdma_cm_id *id)
{
    //log_info("In client function [%d]:%s\n", __LINE__, __func__);
    struct RDMAContext *new_ctx = (struct RDMAContext *)id->context;

    int index = 0;

    new_ctx->k_exch[0]->id = MSG_MR;
    new_ctx->k_exch[0]->md5 = 5555;

    log_info("k_exch md5 is %llu\n", new_ctx->k_exch[0]->md5);

    for (index = 0; index < MAX_CONCURRENCY; index++)
    {
        new_ctx->k_exch[0]->key_info[index].addr = (uintptr_t)(new_ctx->ack_mr[index]->addr);
        new_ctx->k_exch[0]->key_info[index].rkey = (new_ctx->ack_mr[index]->rkey);
    }

    //send to myself info to peer
    {
        struct ibv_send_wr wr, *bad_wr = NULL;
        struct ibv_sge sge;

        memset(&wr, 0, sizeof(wr));

        wr.wr_id = (uintptr_t)id;
        wr.opcode = IBV_WR_SEND;
        wr.sg_list = &sge;
        wr.num_sge = 1;
        wr.send_flags = IBV_SEND_SIGNALED;

        sge.addr = (uintptr_t)(new_ctx->k_exch[0]);
        sge.length = sizeof(KeyExchanger);
        sge.lkey = new_ctx->k_exch_mr[0]->lkey;

        TEST_NZ(ibv_post_send(id->qp, &wr, &bad_wr));
    }
    log_info("share my registed mem rx_buffer for peer write to\n");
}
#include "RDMABase.h"
#include <rdma/rdma_cma.h>

//50 M for default size;

#include <string>
#include <vector>
#include <iostream>
#include <thread>
#include <atomic>
#include <unordered_map>

#include <cassert>
#include <cstdlib>
#include <cstring>
#include <cstdio>

#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>
#include <sys/time.h>
#include <stdlib.h>
#include <stdarg.h>

static struct timeval start_, now_;

void RDMABase::rc_die(const char *reason)
{
    extern int errno;
    fprintf(stderr, "%s\nstrerror= %s\n", reason, strerror(errno));
    exit(-1);
}

void RDMABase::log_info(const char *format, ...)
{
    char now_time[32];
    char s[1024];
    char content[1024];
    //char *ptr = content;
    struct tm *tmnow;
    struct timeval tv;
    bzero(content, 1024);
    va_list arg;
    va_start(arg, format);
    vsprintf(s, format, arg);
    va_end(arg);

    gettimeofday(&tv, NULL);
    tmnow = localtime(&tv.tv_sec);

    sprintf(now_time, "%04d/%02d/%02d %02d:%02d:%02d:%06ld ",
            tmnow->tm_year + 1900, tmnow->tm_mon + 1, tmnow->tm_mday, tmnow->tm_hour,
            tmnow->tm_min, tmnow->tm_sec, tv.tv_usec);

    sprintf(content, "%s %s", now_time, s);
    printf("%s", content);
}

void RDMABase::rdma_write_remote(struct rdma_cm_id *id, uint32_t len, uint32_t index)
{
    //log_info("In function [%d]:%s\n", __LINE__, __func__);
    struct RDMAContext *new_ctx = (struct RDMAContext *)id->context;

    struct ibv_send_wr wr, *bad_wr = NULL;
    struct ibv_sge sge;

    memset(&wr, 0, sizeof(wr));

    wr.wr_id = (uintptr_t)id;

    wr.opcode = IBV_WR_RDMA_WRITE_WITH_IMM;
    wr.send_flags = IBV_SEND_SIGNALED;
    wr.imm_data = index; //htonl(index);
    wr.wr.rdma.remote_addr = new_ctx->peer_addr[index];
    wr.wr.rdma.rkey = new_ctx->peer_rkey[index];

    if (len)
    {
        wr.sg_list = &sge;
        wr.num_sge = 1;

        sge.addr = (uintptr_t)new_ctx->buffer[index];
        sge.length = len;
        sge.lkey = new_ctx->buffer_mr[index]->lkey;
    }

    TEST_NZ(ibv_post_send(id->qp, &wr, &bad_wr));
}

void RDMABase::rdma_post_receive(struct rdma_cm_id *id, uint32_t index)
{
    //log_info("In function [%d]:%s\n", __LINE__, __func__);
    struct ibv_recv_wr wr, *bad_wr = NULL;
    memset(&wr, 0, sizeof(wr));
    wr.wr_id = (uint64_t)id;
    wr.sg_list = NULL;
    wr.num_sge = 0;

    TEST_NZ(ibv_post_recv(id->qp, &wr, &bad_wr));
}
void RDMABase::rdma_ack_remote(struct rdma_cm_id *id, uint32_t index)
{
    //log_info("In function [%d]:%s\n", __LINE__, __func__);
    struct RDMAContext *new_ctx = (struct RDMAContext *)id->context;

    struct ibv_send_wr wr, *bad_wr = NULL;
    struct ibv_sge sge;

    memset(&wr, 0, sizeof(wr));

    wr.wr_id = (uintptr_t)id;

    wr.opcode = IBV_WR_RDMA_WRITE_WITH_IMM;
    wr.send_flags = IBV_SEND_SIGNALED;
    wr.imm_data = index; //htonl(index);
    wr.wr.rdma.remote_addr = new_ctx->peer_addr[index];
    wr.wr.rdma.rkey = new_ctx->peer_rkey[index];

    new_ctx->ack[index]->index = index;

    {
        wr.sg_list = &sge;
        wr.num_sge = 1;

        sge.addr = (uintptr_t)new_ctx->ack[index];
        sge.length = sizeof(ACKMessage);
        sge.lkey = new_ctx->ack_mr[index]->lkey;
    }

    TEST_NZ(ibv_post_send(id->qp, &wr, &bad_wr));
}

void *RDMABase::corcurency_recv_by_RDMA(struct ibv_wc *wc, uint32_t &recv_len)
{
    //log_info("In function [%d]:%s\n", __LINE__, __func__);

    struct rdma_cm_id *id = (struct rdma_cm_id *)(uintptr_t)wc->wr_id;
    struct RDMAContext *ctx = (struct RDMAContext *)id->context;
    //void *_data = nullptr;

    if (wc->opcode == IBV_WC_RECV_RDMA_WITH_IMM)
    {
        //log_info("recv with IBV_WC_RECV_RDMA_WITH_IMM\n");
        //log_info("imm_data is %d\n", wc->imm_data);
        //uint32_t size = ntohl(wc->imm_data);
        uint32_t index = wc->imm_data;
        uint32_t size = *((uint32_t *)(ctx->buffer[index]));
        char *recv_data_ptr = ctx->buffer[index] + sizeof(uint32_t);

        recv_len = size;
        //_data = (void *)std::malloc(sizeof(char) * size);
        /*
        if (_data == nullptr)
        {
            printf("fatal error in recv data malloc!!!!\n");
            exit(-1);
        }
        std::memcpy(_data, recv_data_ptr, size);
*/
        rdma_post_receive(id, wc->imm_data);
        rdma_ack_remote(id, wc->imm_data);
        //log_info("[%d] recv data: %s\n", ctx->client_index, recv_data_ptr);
        recv_count_ += size;
        add_performance(size);
        if (recv_count_ % 50000000 == 0)
        {
            /*
            gettimeofday(&now_, NULL);
            //float time_cost = (tend - tstart) / CLOCKS_PER_SEC;
            float time_cost = (now_.tv_usec - start_.tv_usec) / 1000000.0 + now_.tv_sec - start_.tv_sec;
            printf("Recv data: %f Gbps\n", 8 * (recv_count_ / 1000.0 / 1000 / 1000) / time_cost);
            recv_count_ = 0;
            start_ = now_;
            */
        }
    }
    else if (wc->opcode == IBV_WC_RECV)
    {
        switch (ctx->k_exch[1]->id)
        {
        case MSG_MR:
        {
            log_info("recv MD5 is %llu\n", ctx->k_exch[1]->md5);
            log_info("imm_data is %d\n", wc->imm_data);
            for (int index = 0; index < MAX_CONCURRENCY; index++)
            {
                ctx->peer_addr[index] = ctx->k_exch[1]->key_info[index].addr;
                ctx->peer_rkey[index] = ctx->k_exch[1]->key_info[index].rkey;
                struct sockaddr_in *client_addr = (struct sockaddr_in *)rdma_get_peer_addr(id);
                //printf("client[%s,%d] to ", inet_ntoa(client_addr->sin_addr), client_addr->sin_port);
                //printf("server ack %d: %p  ", index, ctx->peer_addr[index]);
                //printf("my buffer addr: %d %p\n", index, ctx->buffer_mr[index]->addr);
            }
        }
        break;
        default:
            break;
        }
    }
    return nullptr;
}

void *RDMABase::send_tensor(struct rdma_cm_id *id, uint32_t index)
{
    //log_info("In function [%d]:%s\n", __LINE__, __func__);
    struct RDMAContext *ctx = (struct RDMAContext *)id->context;

    std::string msg = "Hello, World : index " + std::to_string(index);
    /*encode msg_length and buffer*/
    uint32_t msg_len = msg.length();

    if ((msg_len + sizeof(uint32_t)) > BUFFER_SIZE)
    {
        perror("fatal error, send msg length is too long\n");
        exit(-1);
    }
    size_t bytes = 1000 * 1000;
    char *_buff = ctx->buffer[index];
    *((uint32_t *)_buff) = bytes;
    //std::memcpy(_buff, (char *)(&msg_len), sizeof(uint32_t));
    //_buff += sizeof(uint32_t);
    //std::memcpy(_buff, msg.c_str(), msg_len);
    //rdma_write_remote(id, msg_len + sizeof(uint32_t), index);
    rdma_write_remote(id, bytes, index);

    return NULL;
}

void *RDMABase::concurrency_send_by_RDMA(struct ibv_wc *wc, int &mem_used)
{
    //log_info("In function [%d]:%s\n", __LINE__, __func__);
    struct rdma_cm_id *id = (struct rdma_cm_id *)(uintptr_t)wc->wr_id;
    struct RDMAContext *ctx = (struct RDMAContext *)id->context;

    switch (wc->opcode)
    {
    case IBV_WC_RECV_RDMA_WITH_IMM:
    {
        rdma_post_receive(id, wc->imm_data);
        send_tensor(id, wc->imm_data);
        break;
    }
    case IBV_WC_RECV:
    {
        if (MSG_MR == ctx->k_exch[1]->id)
        {
            log_info("Exchange: recv MD5 is %llu\n", ctx->k_exch[1]->md5);
            for (int index = 0; index < MAX_CONCURRENCY; index++)
            {
                //reserved the (buffer)key info from server.
                ctx->peer_addr[index] = ctx->k_exch[1]->key_info[index].addr;
                ctx->peer_rkey[index] = ctx->k_exch[1]->key_info[index].rkey;
                struct sockaddr_in *client_addr = (struct sockaddr_in *)rdma_get_peer_addr(id);
                //printf("server[%s,%d] to ", inet_ntoa(client_addr->sin_addr), client_addr->sin_port);
                //printf("client buffer %d: %lu\n", index, ctx->peer_addr[index]);
                //printf("my ach addr: %d %p\n", index, ctx->ack_mr[index]->addr);
            }
            /**send one tensor...**/
            send_tensor(id, 0);
            mem_used++;
        }
        break;
    }
    case IBV_WC_RDMA_WRITE:
    {
        //log_info("IBV_WC_RDMA_WRITE\n");
        break;
    }
    case IBV_WC_RDMA_READ:
    {
        //log_info("IBV_WC_RDMA_READ\n");
        break;
    }
    case IBV_WC_SEND:
    {
        //log_info("IBV_WC_SEND\n");
        break;
    }
    default:
        break;
    }

    return NULL;
}

void *RDMABase::recv_poll_cq(void *_id)
{
    //log_info("In function [%d]:%s\n", __LINE__, __func__);
    struct ibv_cq *cq = NULL;
    struct ibv_wc wc[MAX_CONCURRENCY * 2];
    struct rdma_cm_id *id = (rdma_cm_id *)_id;

    struct RDMAContext *ctx = (struct RDMAContext *)id->context;
    void *ev_ctx = NULL;

    while (true)
    {
        TEST_NZ(ibv_get_cq_event(ctx->comp_channel, &cq, &ev_ctx));
        ibv_ack_cq_events(cq, 1);
        TEST_NZ(ibv_req_notify_cq(cq, 0));

        int wc_num = ibv_poll_cq(cq, MAX_CONCURRENCY * 2, wc);

        for (int index = 0; index < wc_num; index++)
        {
            if (wc[index].status == IBV_WC_SUCCESS)
            {
                /*****here to modified recv* wc---->wc[index]****/
                //printf("in receive poll cq\n");

                uint32_t recv_len;
                corcurency_recv_by_RDMA(&wc[index], recv_len);
            }
            else
            {
                printf("\nwc = %s\n", ibv_wc_status_str(wc[index].status));
                rc_die("poll_cq: status is not IBV_WC_SUCCESS");
            }
        }
    }
    return NULL;
}
void *RDMABase::send_poll_cq(void *_id)
{
    //log_info("In function [%d]:%s\n", __LINE__, __func__);
    struct ibv_cq *cq = NULL;
    struct ibv_wc wc[MAX_CONCURRENCY * 2];
    struct rdma_cm_id *id = (rdma_cm_id *)_id;

    struct RDMAContext *ctx = (struct RDMAContext *)id->context;
    void *ev_ctx = NULL;

    int mem_used = 0;

    while (1)
    {
        TEST_NZ(ibv_get_cq_event(ctx->comp_channel, &cq, &ev_ctx));
        ibv_ack_cq_events(cq, 1);
        TEST_NZ(ibv_req_notify_cq(cq, 0));

        int wc_num = ibv_poll_cq(cq, MAX_CONCURRENCY * 2, wc);

        if (wc_num < 0)
        {
            perror("fatal error in ibv_poll_cq, -1");
            exit(-1);
        }

        for (int index = 0; index < wc_num; index++)
        {
            if (wc[index].status == IBV_WC_SUCCESS)
            {
                concurrency_send_by_RDMA(&wc[index], mem_used);
            }
            else
            {
                printf("\nwc = %s\n", ibv_wc_status_str(wc[index].status));
                rc_die("poll_cq: status is not IBV_WC_SUCCESS");
            }
        }
        if (mem_used)
        {
            //struct RDMAContext *ctx = (struct RDMAContext *)id->context;
            for (mem_used; mem_used < MAX_CONCURRENCY; mem_used++)
            {
                send_tensor(id, mem_used);
            } /*send used next buffer*/
        }
    }
    return NULL;
}

struct ibv_pd *RDMABase::rc_get_pd(struct rdma_cm_id *id)
{
    struct RDMAContext *ctx = (struct RDMAContext *)id->context;
    return ctx->pd;
}

void RDMABase::rdma_build_params(struct rdma_conn_param *params)
{
    memset(params, 0, sizeof(*params));

    params->initiator_depth = params->responder_resources = 1;
    params->rnr_retry_count = 7; /* infinite retry */
    params->retry_count = 7;
}

void RDMABase::rdma_build_context(struct rdma_cm_id *id)
{
    //log_info("In function [%d]:%s\n", __LINE__, __func__);
    struct RDMAContext *s_ctx = (struct RDMAContext *)malloc(sizeof(struct RDMAContext));
    s_ctx->ibv_ctx = id->verbs;
    TEST_Z(s_ctx->pd = ibv_alloc_pd(s_ctx->ibv_ctx));
    TEST_Z(s_ctx->comp_channel = ibv_create_comp_channel(s_ctx->ibv_ctx));
    TEST_Z(s_ctx->cq = ibv_create_cq(s_ctx->ibv_ctx, MAX_CONCURRENCY * 4 + 10, NULL, s_ctx->comp_channel, 0));
    TEST_NZ(ibv_req_notify_cq(s_ctx->cq, 0));
    id->context = (void *)s_ctx;
}

void RDMABase::rdma_build_qp_attr(struct ibv_qp_init_attr *qp_attr, struct rdma_cm_id *id)
{
    //log_info("In function [%d]:%s\n", __LINE__, __func__);
    struct RDMAContext *ctx = (struct RDMAContext *)id->context;
    memset(qp_attr, 0, sizeof(*qp_attr));
    qp_attr->send_cq = ctx->cq;
    qp_attr->recv_cq = ctx->cq;
    qp_attr->qp_type = IBV_QPT_RC;

    qp_attr->cap.max_send_wr = MAX_CONCURRENCY + 20 + 1;
    qp_attr->cap.max_recv_wr = MAX_CONCURRENCY + 20 + 1;
    qp_attr->cap.max_send_sge = 1;
    qp_attr->cap.max_recv_sge = 1;
    {
        //qp_attr->retry_cnt = 7;
        //qp_attr->rnr_retry = 7;
    }
}

void RDMABase::rdma_build_connection(struct rdma_cm_id *id)
{
    struct ibv_qp_init_attr qp_attr;
    rdma_build_context(id);
    rdma_build_qp_attr(&qp_attr, id);

    struct RDMAContext *ctx = (struct RDMAContext *)id->context;
    TEST_NZ(rdma_create_qp(id, ctx->pd, &qp_attr));
}

void RDMABase::rdma_on_pre_conn(struct rdma_cm_id *id)
{
    //log_info("In function [%d]:%s\n", __LINE__, __func__);
    struct RDMAContext *new_ctx = (struct RDMAContext *)id->context;

    for (int index = 0; index < MAX_CONCURRENCY; index++)
    {
        posix_memalign((void **)(&(new_ctx->buffer[index])), sysconf(_SC_PAGESIZE), BUFFER_SIZE);
        TEST_Z(new_ctx->buffer_mr[index] = ibv_reg_mr(rc_get_pd(id), new_ctx->buffer[index], BUFFER_SIZE, IBV_ACCESS_LOCAL_WRITE | IBV_ACCESS_REMOTE_WRITE));
        //printf("buffer %d :%p\n", index, new_ctx->buffer_mr[index]->addr);

        posix_memalign((void **)(&(new_ctx->ack[index])), sysconf(_SC_PAGESIZE), sizeof(ACKMessage));
        TEST_Z(new_ctx->ack_mr[index] = ibv_reg_mr(rc_get_pd(id), new_ctx->ack[index],
                                                   sizeof(ACKMessage), IBV_ACCESS_LOCAL_WRITE | IBV_ACCESS_REMOTE_WRITE));
        //printf("ack %d :%p\n", index, new_ctx->ack_mr[index]->addr);
    }
    //log_info("register %d MB tx_buffer and rx_ack, %d, %d\n", MAX_CONCURRENCY * BUFFER_SIZE / 1000 / 1000.0, MAX_CONCURRENCY, BUFFER_SIZE);
    //log_info("Malloc: %d MB memory\n", MAX_CONCURRENCY * BUFFER_SIZE / 1000 / 1000);

    {
        posix_memalign((void **)(&(new_ctx->k_exch[0])), sysconf(_SC_PAGESIZE), sizeof(KeyExchanger));
        TEST_Z(new_ctx->k_exch_mr[0] = ibv_reg_mr(rc_get_pd(id), new_ctx->k_exch[0], sizeof(KeyExchanger), IBV_ACCESS_LOCAL_WRITE | IBV_ACCESS_REMOTE_WRITE));

        posix_memalign((void **)(&(new_ctx->k_exch[1])), sysconf(_SC_PAGESIZE), sizeof(KeyExchanger));
        TEST_Z(new_ctx->k_exch_mr[1] = ibv_reg_mr(rc_get_pd(id), new_ctx->k_exch[1], sizeof(KeyExchanger), IBV_ACCESS_LOCAL_WRITE | IBV_ACCESS_REMOTE_WRITE));
    }
    //log_info("register rx_k_exch (index:0) and tx_k_exch (index:1)\n");

    struct ibv_recv_wr wr, *bad_wr = NULL;
    struct ibv_sge sge;

    memset(&wr, 0, sizeof(wr));

    wr.wr_id = (uintptr_t)id;
    wr.sg_list = &sge;
    wr.num_sge = 1;

    sge.addr = (uintptr_t)(new_ctx->k_exch[1]);
    sge.length = sizeof(KeyExchanger);
    sge.lkey = new_ctx->k_exch_mr[1]->lkey;

    TEST_NZ(ibv_post_recv(id->qp, &wr, &bad_wr));

    for (uint32_t index = 0; index < MAX_CONCURRENCY; index++)
    {
        //log_info("post recv index : %u\n", index);
        rdma_post_receive(id, index);
    }
}

/**server on connection***/
/* 
void RDMABase::rdma_on_connection(struct rdma_cm_id *id)
{
    struct RDMAContext *new_ctx = (struct RDMAContext *)id->context;

    int index = 0;

    new_ctx->k_exch[0]->id = MSG_MR;
    if (is_server)
        new_ctx->k_exch[0]->md5 = 6666;
    else
        new_ctx->k_exch[0]->md5 = 5555;

    log_info("k_exch md5 is %llu\n", new_ctx->k_exch[0]->md5);
    if (is_server)
    {
        for (index = 0; index < MAX_CONCURRENCY; index++)
        {
            new_ctx->k_exch[0]->key_info[index].addr = (uintptr_t)(new_ctx->buffer_mr[index]->addr);
            new_ctx->k_exch[0]->key_info[index].rkey = (new_ctx->buffer_mr[index]->rkey);
        }
    }
    else
    {
        for (index = 0; index < MAX_CONCURRENCY; index++)
        {
            new_ctx->k_exch[0]->key_info[index].addr = (uintptr_t)(new_ctx->ack_mr[index]->addr);
            new_ctx->k_exch[0]->key_info[index].rkey = (new_ctx->ack_mr[index]->rkey);
        }
    }

    //send to myself info to peer
    {
        struct ibv_send_wr wr, *bad_wr = NULL;
        struct ibv_sge sge;

        memset(&wr, 0, sizeof(wr));

        wr.wr_id = (uintptr_t)id;
        wr.opcode = IBV_WR_SEND;
        wr.sg_list = &sge;
        wr.num_sge = 1;
        wr.send_flags = IBV_SEND_SIGNALED;

        sge.addr = (uintptr_t)(new_ctx->k_exch[0]);
        sge.length = sizeof(KeyExchanger);
        sge.lkey = new_ctx->k_exch_mr[0]->lkey;

        TEST_NZ(ibv_post_send(id->qp, &wr, &bad_wr));
    }
    log_info("share my registed mem rx_buffer for peer write to\n");
}*/

void RDMABase::rdma_on_disconnect(struct rdma_cm_id *id)
{
    //log_info("In function [%d]:%s\n", __LINE__, __func__);
    struct RDMAContext *new_ctx = (struct RDMAContext *)id->context;

    for (int index = 0; index < MAX_CONCURRENCY; index++)
    {
        ibv_dereg_mr(new_ctx->buffer_mr[index]);
        ibv_dereg_mr(new_ctx->ack_mr[index]);

        free(new_ctx->buffer[index]);
        free(new_ctx->ack[index]);
    }

    {
        ibv_dereg_mr(new_ctx->k_exch_mr[0]);
        ibv_dereg_mr(new_ctx->k_exch_mr[1]);

        free(new_ctx->k_exch[0]);
        free(new_ctx->k_exch[1]);
    }
    //log_info("Free: %d MB memory\n", MAX_CONCURRENCY * BUFFER_SIZE / 1000 / 1000);
    free(new_ctx);
}
#include <mutex>
#include <iostream>
#include <thread>
std::mutex mtx;
size_t perf_data = 0;
void RDMABase::show_performance()
{
    size_t tmp_perf = 0;
    {
        std::lock_guard<std::mutex> lg(mtx);
        tmp_perf = perf_data;
        perf_data = 0;
    }
    printf("total performance: %f Gbps\n", 8.0 * tmp_perf / 1000 / 1000 / 1000);
}
void RDMABase::add_performance(size_t data_num)
{
    std::lock_guard<std::mutex> lg(mtx);
    perf_data += data_num;
}
